const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict');
const root=path.resolve(__dirname,'..','app');
global.window=global;global.crypto=require('node:crypto').webcrypto;
const settings=new Map();global.localStorage={getItem:k=>settings.get(k)||null,setItem:(k,v)=>settings.set(k,v)};
for(const file of ['data/seed.js','core/evidence.js','core/discovery.js','core/assessment.js','core/matching.js','core/actions.js','core/analysis.js','core/pdf.js','core/store.js','core/localApi.js'])vm.runInThisContext(fs.readFileSync(path.join(root,file),'utf8'),{filename:file});
let content=null;
const dataDir={async getFileHandle(name,{create=false}={}) {
 assert.equal(name,'workspace.json');
 if(content===null && !create) {let e=new Error('not found');e.name='NotFoundError';throw e;}
 return {
  async getFile(){return{size:content?.length||0,text:async()=>content}},
  async createWritable(){return{async write(s){content=s;},async close(){},async abort(){}}}
 };
}};
global.showDirectoryPicker=async()=>({name:'InnovationRadar',getDirectoryHandle:async(name,opts)=>{assert.equal(name,'data');return dataDir;}});
(async()=>{
 assert.equal(await RadarStore.openFolder(),true);
 assert.equal(RadarStore.folderName,'InnovationRadar');
 assert(content.includes('innovation-radar-local-backup'));
 await RadarLocalApi.request('/api/needs',{method:'POST',body:JSON.stringify({title:'Problemy z ogrzewaniem budynków',organization_name:'Urząd demo',problem:'Instytucja chce rozwiązać problemy z ogrzewaniem budynków.',domain_tags:['energia']})});
 assert(JSON.parse(content).data.needs.length===1);
 console.log('PASS folder selection and write-on-save');
})().catch(e=>{console.error(e);process.exit(1)})
