'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const app=path.join(__dirname,'../app');
global.window=global;if(!global.crypto)global.crypto=require('node:crypto').webcrypto;
const local=new Map();global.localStorage={getItem:k=>local.get(k)||null,setItem:(k,v)=>local.set(k,v)};
for(const name of ['data/seed.js','core/evidence.js','core/discovery.js','core/assessment.js','core/matching.js','core/actions.js','core/analysis.js','core/pdf.js','core/store.js','core/localApi.js','core/sources/openalex.js','core/sources/ncbr.js','core/onlineSearch.js']){
 vm.runInThisContext(fs.readFileSync(path.join(app,name),'utf8'),{filename:name});
}
const test=(name,v)=>{assert(v,name);console.log('PASS '+name);};
(async()=>{
  const work={id:'https://openalex.org/W123456789',display_name:'Adaptive learning methods for students',
    publication_date:'2025-02-12',doi:'https://doi.org/10.1234/example',
    authorships:[{author:{display_name:'Testowa Autorka'},institutions:[{display_name:'Uniwersytet Testowy'}]}],
    abstract_inverted_index:{Adaptive:[0],learning:[1],improves:[2],students:[3],with:[4],teachers:[5],and:[6],feedback:[7]}};
  const converted=RadarOpenAlex.convert(work,'2026-11-21T16:00:00Z');
  test('reconstructs OpenAlex abstract',converted.description==='Adaptive learning improves students with teachers and feedback');
  test('source URL and publication date retained',converted.url.includes('openalex.org/W123456789')&&converted.published_at==='2025-02-12');
  test('no invented problem or impact',RadarOnlineSearch.toCandidate(converted).fields.problem===''&&RadarOnlineSearch.toCandidate(converted).fields.claimed_impact==='');
  const mockFetch=async url=>{assert(url.includes('search=')&&url.includes('per_page=5'));return {ok:true,json:async()=>({meta:{count:1},results:[work]})};};
  const initial=JSON.stringify(RadarStore.backup().data);
  const report=await RadarOnlineSearch.search('edukacja',['openalex','ncbr'],5,{fetchImpl:mockFetch});
  test('real-shaped mocked API + curated source combined',report.sources.length===2&&report.sources[0].live===true&&report.sources[1].live===false);
  test('at least one real linked Polish NCBR project',report.candidates.some(c=>c.record.source_id==='ncbr'&&c.record.url.startsWith('https://www.gov.pl/web/ncbr/')));
  test('online candidates have assessment, matches and recommendations',report.candidates.every(c=>c.assessment && Array.isArray(c.matches) && c.actions.length>0));
  test('online search does not alter local storage',JSON.stringify(RadarStore.backup().data)===initial);
  const repeated=RadarOnlineSearch.deduplicate([converted,{...converted,record_id:'W22334455'}, {...converted,title:'Different title',url:'https://openalex.org/W111',doi:'https://doi.org/other'}]);
  test('deduplication by DOI and title',repeated.unique.length===2&&repeated.duplicates.length===1);
  const reportFailed=await RadarOnlineSearch.search('edukacja',['openalex','ncbr'],5,{fetchImpl:async()=>{throw new TypeError('Blocked CORS');}});
  test('failed live API is reported, curated results survive',reportFailed.errors.length===1&&reportFailed.candidates.length>=1);
  test('reports connection errors without claiming remote success',reportFailed.errors[0].message.includes('CORS') && reportFailed.sources.every(s=>!s.live));
  const record=report.candidates.find(c=>c.record.source_id==='ncbr');
  const fields=record.fields;
  const created=await RadarLocalApi.request('/api/innovations',{method:'POST',body:JSON.stringify({...fields,
    organization_name:fields.organization_name,source_mode:'online',problem:fields.problem,solution:fields.solution})});
  test('confirmed online record stores URL and provider',created.innovation.source_url===record.record.url&&created.innovation.source_provider==='ncbr');
  const saved=await RadarLocalApi.request('/api/innovations/'+created.innovation.id);
  test('online source citation kept without fictional line number',saved.evidence.records[0].source_url===record.record.url && saved.evidence.records[0].line_number===null);
  test('backup schema stays v2',RadarStore.backup().version===2);
  const removed=RadarEvidence.forRecord([{field:'title',source_name:'Test',quote:'Wrong title',source_url:'https://openalex.org/W123',evidence_type:'online_metadata'}],{title:'Different title'});
  test('edited source metadata cannot support different claim',removed.length===0);
  test('unsafe URL rejected',RadarOnlineSearch.safeHttps('javascript:alert(1)')===''&&RadarOnlineSearch.toCandidate({...converted,url:'javascript:evil()'})===null);
  await assert.rejects(()=>RadarOnlineSearch.search('te',['openalex'],5,{fetchImpl:mockFetch}),/3–180/);
  test('invalid search rejected',true);
  const limits=RadarOpenAlex.buildUrl('edukacja',8);
  test('API URL uses encoded search parameters',new URL(limits).searchParams.get('search')==='edukacja');
  console.log('Online integration tests: 17/17');
})().catch(e=>{console.error(e);process.exit(1)});
