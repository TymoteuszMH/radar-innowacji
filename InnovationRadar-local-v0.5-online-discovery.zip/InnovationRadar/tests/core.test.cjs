const fs=require('node:fs');
const path=require('node:path');
const assert=require('node:assert/strict');
const dir=path.join(__dirname,'..','app');
global.window=global;
global.crypto=require('node:crypto').webcrypto;
const cache=new Map();
global.localStorage={getItem:key=>cache.get(key)||null,setItem:(key,val)=>cache.set(key,val)};
for(const src of ['data/seed.js','core/evidence.js','core/discovery.js','core/assessment.js','core/matching.js','core/actions.js','core/analysis.js','core/pdf.js','core/store.js','core/localApi.js']) require(path.join(dir,src));
(async()=>{
 let checks=0;
 const check=(name,val)=>{assert(val,name);checks++;console.log('PASS',name)};
 const dash=await RadarLocalApi.request('/api/dashboard');
 check('10 seeded innovations',dash.counts.innovations===10);
 check('6 seeded needs',dash.counts.needs===6);
 const ind=await RadarLocalApi.request('/api/innovations/inn-adaptive');
 check('innovation score',ind.assessment.score!==null);
 check('innovation matches',ind.matches.length>0);
 const need=await RadarLocalApi.request('/api/needs/need-learning');
 check('reverse matches',need.matches.some(m=>m.innovation.id==='inn-adaptive'));
 const pdf1=new Blob([fs.readFileSync(path.join(__dirname,'..','demo_documents/edukacja_adaptacyjne_powtorki.pdf'))],{type:'application/pdf'});
 const pdf2=new Blob([fs.readFileSync(path.join(__dirname,'..','demo_documents/samorzad_trasy_odpadow.pdf'))],{type:'application/pdf'});
 for(const [name,pdf] of [['school',pdf1],['municipality',pdf2]]){
   const raw=await RadarPdf.textFromPdf(pdf);
   console.log(name, 'raw snippet:',raw.slice(0,240).replace(/\n/g,' | '));
   const extracted=RadarAnalysis.previewExtract(raw,'example.pdf');
   console.log(name,'fields:',extracted.fields);
   check(name+' pdf text',raw.length>200);
   check(name+' pdf extracted title',extracted.fields.title?.length>8);
   check(name+' pdf extracted problem',extracted.fields.problem?.length>25);
   check(name+' pdf extracted solution',extracted.fields.solution?.length>25);
 }
 const created=await RadarLocalApi.request('/api/innovations',{method:'POST',body:JSON.stringify({organization_name:'Szkoła nowa',title:'Nowy projekt pilotażowy',problem:'Problem polega na braku informacji o zmianach w programie szkolnym.',solution:'Prowadzenie warsztatów i aplikacji do wymiany wiedzy w szkole.',stage:'pilot',innovation_type:'educational',domain_tags:['edukacja'],target_groups:['uczniowie'],keywords:['szkoła']})});
 check('new innovation created',!!created.innovation.id);
 check('new innovation in catalog',(await RadarLocalApi.request('/api/innovations')).total===11);
 check('browser storage persisted',cache.size===1);
 const backup=RadarStore.backup();
 check('backup data',backup.data.innovations.length===1);
 RadarStore.restoreBackup(backup);
 check('backup restore count',(await RadarLocalApi.request('/api/innovations')).total===11);
 const createdNeed=await RadarLocalApi.request('/api/needs',{method:'POST',body:JSON.stringify({organization_name:'Urząd demo',title:'Poprawa komunikacji',problem:'Mieszkańcy mają trudność z dostępem do dokumentów i odpowiedzi.',desired_outcome:'Szybszy dostęp do informacji.',domain_tags:['samorząd'],keywords:['administracja']})});
 check('new need created',!!createdNeed.need.id);
 console.log('Checks passed',checks);
})().catch(err=>{console.error(err);process.exit(1)})
